# Autogen AI Personal Assistant

Build an intelligent multi-agent AI assistant that handles tasks like managing calendars, reminders, emails, weather updates, and research.

## Setup

1. Create a virtual environment
2. Install dependencies from `requirements.txt`
3. Add API keys to `.env`
4. Run `autogen_assistant.ipynb` in Jupyter Notebook
